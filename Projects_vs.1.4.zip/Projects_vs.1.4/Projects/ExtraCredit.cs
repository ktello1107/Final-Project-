﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects
{
    public class ExtraCredit
    {
        public string studentfirstName { get; set;}
        public string studentlastName { get; set;}
        public int attendance { get; set;}


    }

}